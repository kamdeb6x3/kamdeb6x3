#!/bin/sh

sudo rm -f /usr/share/applications/Ghidra.desktop
sudo rm -f /usr/share/icons/hicolor/16x16/apps/ghidra.png
sudo rm -f /usr/share/icons/hicolor/22x22/apps/ghidra.png
sudo rm -f /usr/share/icons/hicolor/24x24/apps/ghidra.png
sudo rm -f /usr/share/icons/hicolor/32x32/apps/ghidra.png
sudo rm -f /usr/share/icons/hicolor/48x48/apps/ghidra.png
sudo rm -f /usr/share/icons/hicolor/256x256/apps/ghidra.png
sudo rm -f /usr/share/pixmaps/ghidra.png
