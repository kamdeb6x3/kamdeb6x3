#!/bin/sh

WORKSPACE=$(pwd)
sudo cp -r $WORKSPACE/usr /

